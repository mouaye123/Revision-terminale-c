-- =====================================================================
--  MIGRATION : aligne TON schéma Supabase actuel avec le code du site
--  À coller dans Supabase > SQL Editor > New query > Run.
--  Ne supprime AUCUNE donnée : elle ajoute des colonnes, remplace quelques
--  règles et ajoute des protections. Elle peut être relancée sans danger.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) DOCUMENTS : colonnes dont le site a besoin
--    (les matières et les leçons du site sont dans le code : on les range
--     par clé texte, « philo », « maths »…, et non par identifiant de table)
-- ---------------------------------------------------------------------
alter table public.documents add column if not exists matiere        text;
alter table public.documents add column if not exists lecon          integer;
alter table public.documents add column if not exists chapitre       text not null default '';
alter table public.documents add column if not exists annee_scolaire text;      -- ex. '2025-2026'
alter table public.documents add column if not exists raison         text;      -- motif du dernier signalement
alter table public.documents add column if not exists chemin_mini    text;      -- miniature (liste rapide)

-- L'empreinte du site est une empreinte « visuelle » : deux photos du même devoir
-- ont des empreintes proches mais pas identiques, et deux pages blanches très
-- semblables pourraient avoir la même. On retire donc l'unicité (qui bloquerait
-- des envois légitimes) : les doublons sont repérés et signalés par le site.
do $$
declare c text;
begin
  for c in
    select conname from pg_constraint
    where conrelid = 'public.documents'::regclass
      and contype = 'u'
      and pg_get_constraintdef(oid) = 'UNIQUE (dhash)'
  loop
    execute format('alter table public.documents drop constraint %I', c);
  end loop;
end $$;

-- Contrôles de validité (appliqués aux nouveaux envois)
alter table public.documents drop constraint if exists documents_matiere_check;
alter table public.documents add constraint documents_matiere_check
  check (matiere is null or matiere in
    ('philo','histoire','geographie','francais','maths','sciences','svt','anglais','espagnol','allemand')) not valid;

alter table public.documents drop constraint if exists documents_lecon_check;
alter table public.documents add constraint documents_lecon_check
  check (lecon is null or lecon between 1 and 60) not valid;

alter table public.documents drop constraint if exists documents_annee_scolaire_check;
alter table public.documents add constraint documents_annee_scolaire_check
  check (annee_scolaire is null or annee_scolaire ~ '^[0-9]{4}-[0-9]{4}$') not valid;

alter table public.documents drop constraint if exists documents_titre_long_check;
alter table public.documents add constraint documents_titre_long_check
  check (char_length(titre) <= 60) not valid;

-- ---------------------------------------------------------------------
-- 2) LIMITE : 10 envois par élève et par jour (change le 10 si besoin)
-- ---------------------------------------------------------------------
create or replace function public.limiter_envois()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select count(*) from public.documents
        where auteur_id = new.auteur_id
          and cree_le > now() - interval '24 hours') >= 10 then
    raise exception 'Limite atteinte : 10 devoirs par jour. Réessaie demain.' using errcode = 'P0001';
  end if;
  return new;
end;
$$;

drop trigger if exists avant_envoi on public.documents;
create trigger avant_envoi before insert on public.documents
  for each row execute function public.limiter_envois();

-- ---------------------------------------------------------------------
-- 3) SIGNALEMENTS
--    - on ne peut signaler qu'un document PUBLIÉ ;
--    - les modérateurs peuvent effacer les signalements (quand ils remettent
--      un document en ligne) ;
--    - le motif du dernier signalement est recopié sur le document.
-- ---------------------------------------------------------------------
alter table public.signalements drop constraint if exists signalements_motif_check;
alter table public.signalements add constraint signalements_motif_check
  check (motif in ('classement','illisible','doublon','inapproprie')) not valid;

drop policy if exists "Envoyer un signalement" on public.signalements;
create policy "Envoyer un signalement"
on public.signalements for insert
to authenticated
with check (
  auteur_id = (select auth.uid())
  and exists (
    select 1 from public.documents d
    where d.id = document_id and d.statut = 'publie'
  )
);

drop policy if exists "Moderateurs suppriment les signalements" on public.signalements;
create policy "Moderateurs suppriment les signalements"
on public.signalements for delete
to authenticated
using ((select public.est_moderateur()));

create or replace function public.verifier_signalements()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select count(*) from public.signalements s
        where s.document_id = new.document_id) >= 2 then
    update public.documents
       set statut = 'signale', raison = new.motif
     where id = new.document_id and statut = 'publie';
  end if;
  return new;
end;
$$;

-- ---------------------------------------------------------------------
-- 4) PROFILS : le site envoie le nom choisi sous les clés « nom » et « nom_affiche »
-- ---------------------------------------------------------------------
create or replace function public.creer_profil()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profils (id, nom_affiche)
  values (
    new.id,
    nullif(left(trim(coalesce(new.raw_user_meta_data ->> 'nom_affiche',
                              new.raw_user_meta_data ->> 'nom', '')), 40), '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

-- ---------------------------------------------------------------------
-- 5) STOCKAGE : les miniatures des documents publiés doivent aussi être lisibles
-- ---------------------------------------------------------------------
drop policy if exists "Lire ses fichiers ou fichiers publies" on storage.objects;
create policy "Lire ses fichiers ou fichiers publies"
on storage.objects for select
to authenticated
using (
  bucket_id = 'devoirs'
  and (
    (storage.foldername(name))[1] = (select auth.uid())::text
    or (select public.est_moderateur())
    or exists (
      select 1 from public.documents d
      where (d.chemin_fichier = storage.objects.name
             or d.chemin_mini  = storage.objects.name)
        and d.statut = 'publie'
    )
  )
);

-- ---------------------------------------------------------------------
-- 6) DROITS D'ACCÈS aux tables (les règles RLS ci-dessus restent le vrai filtre)
--    Utile si ton projet n'accorde pas ces droits automatiquement.
-- ---------------------------------------------------------------------
grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on public.documents    to authenticated;
grant select, insert, delete         on public.signalements to authenticated;
grant select, insert, update         on public.progression  to authenticated;
grant select, insert                 on public.resultats    to authenticated;
grant select on public.matieres, public.lecons, public.questions to anon, authenticated;

-- ---------------------------------------------------------------------
-- 7) TE DONNER LE RÔLE ADMIN (APRÈS avoir créé ton compte dans le site)
--    Enlève les deux tirets, mets ton adresse email, puis exécute.
-- ---------------------------------------------------------------------
-- update public.profils set role = 'admin'
--   where id = (select id from auth.users where email = 'ton.adresse@email.com');

-- ---------------------------------------------------------------------
-- 8) VÉRIFICATIONS (facultatif) : enlève les tirets d'une requête pour la lancer
-- ---------------------------------------------------------------------
-- select column_name, data_type from information_schema.columns
--   where table_schema='public' and table_name='documents' order by ordinal_position;
-- select schemaname, tablename, policyname, cmd from pg_policies
--   where schemaname in ('public','storage') order by 1,2,3;
