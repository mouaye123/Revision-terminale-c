# Mise en ligne officielle : ce qui reste à faire

Ta base Supabase existe déjà (tu as exécuté ton script SQL) et le site est déjà branché dessus
(`js/config.js` contient l'adresse du projet et la clé publique `sb_publishable_`).
Il reste ces étapes, dans l'ordre.

## 1. Exécuter `supabase/migration.sql`
Supabase > **SQL Editor** > **New query** > colle tout le fichier > **Run**.
Ce script aligne ta base avec le site (colonnes `matiere`, `lecon`, `chapitre`, `annee_scolaire`,
`raison`, `chemin_mini`, miniatures lisibles, limite de 10 envois par jour, règles de signalement).
Il ne supprime aucune donnée. Si une erreur s'affiche, copie le message et envoie-le.

## 2. Régler l'authentification (Supabase > Authentication)
- **URL Configuration** : mets dans **Site URL** l'adresse de ton site GitHub Pages
  (du type `https://TON-PSEUDO.github.io/NOM-DU-DEPOT/`) et ajoute la même adresse dans **Redirect URLs**.
- **Sign In / Providers > Email** : « Confirm email » est **désactivé** pour un lancement simple
  (les élèves n'ont pas à cliquer un lien reçu par email). Tu peux l'activer plus tard avec un
  service d'envoi d'emails personnalisé (SMTP), car l'envoi gratuit de Supabase est très limité.
- Garde une longueur minimale de mot de passe de 6 ou plus.

## 3. Mettre à jour le dépôt GitHub
1. Remplace TOUS les fichiers du dépôt par ceux de `revision-terminale-c-github.zip`
   (dossiers `css/`, `js/`, `supabase/` et `index.html` à la racine).
2. Supprime l'ancienne ligne `<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2">` si elle
   existe encore : le site n'utilise plus cette bibliothèque (elle n'était pas figée sur une version).
3. Commit, push, puis attends la fin du déploiement dans l'onglet **Actions** / **Pages**.

## 4. Te donner le rôle d'administrateur
1. Ouvre ton site publié > menu > **Se connecter** > **Créer un compte** avec ton email.
2. Dans le SQL Editor, lance la commande en commentaire (section 7 de `migration.sql`) avec ton email.
3. Déconnecte-toi puis reconnecte-toi : la banque a maintenant un onglet **À valider**.
   Pour nommer un autre modérateur : même commande avec `role = 'moderateur'`.

## 5. Test de recette (15 minutes, avec 2 comptes)
- [ ] Compte A : créer un compte, ajouter un devoir (caméra et import), il apparaît dans « Mes envois ».
- [ ] Table Editor > `documents` : la ligne existe avec `statut = attente` ; Storage > `devoirs` : 2 images.
- [ ] Compte B : ne voit rien dans « Publiés ».
- [ ] Admin : banque > « À valider » > ouvrir > **Publier**.
- [ ] Compte B : le devoir est visible (miniature et image en grand).
- [ ] Compte B puis un compte C signalent le devoir : il disparaît de la banque (statut `signale`).
- [ ] Admin : remet le devoir en ligne ; ses signalements sont effacés.
- [ ] Compte A : verrouille une leçon sur un téléphone, ouvre le site sur un autre : elle est verrouillée aussi.
- [ ] Se déconnecter puis se reconnecter garde la progression.

## 6. Avant d'annoncer le site aux élèves
- **Protection des données** : les élèves sont souvent mineurs. N'affiche jamais leur email, rappelle de ne pas
  publier de document avec un nom complet, un téléphone ou une adresse (le site l'écrit déjà au moment de l'envoi).
  Ajoute une courte page « Confidentialité et règles » (qui peut voir quoi, comment demander une suppression).
- **Clés** : seule la clé `sb_publishable_` est dans le site. Ne mets JAMAIS une clé `sb_secret_`, la clé
  `service_role` ou le mot de passe de la base dans le dépôt.
- **Limites de l'offre gratuite** : un projet gratuit est mis en pause après 7 jours sans activité (il se
  réveille depuis le tableau de bord). Surveille l'espace de stockage (Supabase > Storage).
- **Sauvegarde** : exporte de temps en temps tes tables (Table Editor > Export) et garde une copie des images.
